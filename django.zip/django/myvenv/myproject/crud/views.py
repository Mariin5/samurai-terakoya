#テンプレートをレンダリングする関数
from django.shortcuts import render 
#テンプレートを表示させるための処理、TemplateViewを継承してビュークラスをつくる
from django.views.generic import TemplateView, ListView
from .models import Product

#TopVIewが処理名、TopVIew内に書かれてる内容が具体的処理
#ビュークラスの命名：処理内容にViewをつける
class TopView(TemplateView):
    #レンダリングするテンプレート名を指定、TempViewを継承してtemplate_nameにファイルを指定して表示
    template_name = "top.html"

class ProductListView(ListView):
    model = Product
    template_name = "list.html"
    paginated_by = 3
